import json
import logging
import re
import boto3
import time
import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)
client = boto3.client('ecs')
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    deployment_max_age_sec = 240
    ecs_service_name, ecs_cluster_name, sns_topic_arn = event['ecs_service_name'], event['ecs_cluster_name'], event['sns_topic_arn']

    response = client.describe_services(cluster=ecs_cluster_name,services=[ecs_service_name])
    deployments = response['services'][0]['deployments']
    if len(deployments) < 2:
      logger.info('Number of deployments is less than 2, exiting.')
      return

    primary_deployment = (item for item in deployments if item["status"] == "PRIMARY").next()

    primary_deployment_updated_seconds = time.mktime(primary_deployment['updatedAt'].timetuple())
    time_now_seconds = time.mktime(datetime.datetime.now().timetuple())

    primary_deployment_age_sec = time_now_seconds - primary_deployment_updated_seconds

    if primary_deployment_age_sec < deployment_max_age_sec:
      logger.info('Primary deployment age is less than specified limit ' + deployment_max_age_sec)
      return

    logger.info('Failed ECS service deployment detected')

    sns_response = sns_client.publish(
      TopicArn = sns_topic_arn,
      Message = "There is a problem with ECS service " + ecs_service_name + " in ECS cluster " + ecs_cluster_name + ". See AWS web console for more details.",
      Subject = "Failed deploy of ECS service " + ecs_service_name + " detected."
    )

    logger.info(sns_response)
